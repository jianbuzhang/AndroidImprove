using System;
using System.Collections.Generic;
using System.Text;

namespace Socket_Server
{
    class Global
    {
        public static int port = 5050;
        public static List<StateObject> client = new List<StateObject>();
    }
   
}
